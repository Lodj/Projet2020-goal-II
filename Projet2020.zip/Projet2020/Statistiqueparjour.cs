﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Statistiqueparjour : Form
    {
        public Statistiqueparjour()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        /* private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
         {
             e.Graphics.DrawString(chart1, Font, Brushes.Black, 100, 100);
         }*/

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }
    }
}
