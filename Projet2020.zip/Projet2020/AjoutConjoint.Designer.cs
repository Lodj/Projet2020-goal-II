﻿namespace Projet2020
{
    partial class AjoutConjoint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txt_fonction = new System.Windows.Forms.TextBox();
            this.cmb_etatsante = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bt_ajouttache = new System.Windows.Forms.Button();
            this.bt_enregister = new System.Windows.Forms.Button();
            this.cmb_type = new System.Windows.Forms.ComboBox();
            this.cmb_description = new System.Windows.Forms.ComboBox();
            this.txt_personneimplique = new System.Windows.Forms.TextBox();
            this.txt_emplacement = new System.Windows.Forms.TextBox();
            this.txt_tolerance = new System.Windows.Forms.TextBox();
            this.txt_nomtache = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Fonction du conjoint";
            // 
            // txt_fonction
            // 
            this.txt_fonction.Location = new System.Drawing.Point(192, 52);
            this.txt_fonction.Name = "txt_fonction";
            this.txt_fonction.Size = new System.Drawing.Size(200, 20);
            this.txt_fonction.TabIndex = 15;
            // 
            // cmb_etatsante
            // 
            this.cmb_etatsante.FormattingEnabled = true;
            this.cmb_etatsante.Items.AddRange(new object[] {
            "Sain et sauve",
            "En forme",
            "Un peu malade",
            "Pas totalement en forme",
            "Malade",
            "Très malade"});
            this.cmb_etatsante.Location = new System.Drawing.Point(192, 26);
            this.cmb_etatsante.Name = "cmb_etatsante";
            this.cmb_etatsante.Size = new System.Drawing.Size(200, 21);
            this.cmb_etatsante.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Etat de santé du conjoint";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(192, 170);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 49;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(192, 144);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 48;
            // 
            // bt_ajouttache
            // 
            this.bt_ajouttache.Location = new System.Drawing.Point(447, 255);
            this.bt_ajouttache.Name = "bt_ajouttache";
            this.bt_ajouttache.Size = new System.Drawing.Size(108, 73);
            this.bt_ajouttache.TabIndex = 47;
            this.bt_ajouttache.Text = "Ajoter une autre tache";
            this.bt_ajouttache.UseVisualStyleBackColor = true;
            this.bt_ajouttache.Click += new System.EventHandler(this.bt_ajouttache_Click);
            // 
            // bt_enregister
            // 
            this.bt_enregister.Location = new System.Drawing.Point(447, 144);
            this.bt_enregister.Name = "bt_enregister";
            this.bt_enregister.Size = new System.Drawing.Size(108, 72);
            this.bt_enregister.TabIndex = 46;
            this.bt_enregister.Text = "Enrégistrer";
            this.bt_enregister.UseVisualStyleBackColor = true;
            this.bt_enregister.Click += new System.EventHandler(this.bt_enregister_Click);
            // 
            // cmb_type
            // 
            this.cmb_type.FormattingEnabled = true;
            this.cmb_type.Items.AddRange(new object[] {
            "Normale",
            "Urgente",
            "Habituelle",
            "Inhabituelle"});
            this.cmb_type.Location = new System.Drawing.Point(192, 405);
            this.cmb_type.Name = "cmb_type";
            this.cmb_type.Size = new System.Drawing.Size(200, 21);
            this.cmb_type.TabIndex = 45;
            // 
            // cmb_description
            // 
            this.cmb_description.FormattingEnabled = true;
            this.cmb_description.Items.AddRange(new object[] {
            "Non important",
            "Important",
            "Très important"});
            this.cmb_description.Location = new System.Drawing.Point(192, 378);
            this.cmb_description.Name = "cmb_description";
            this.cmb_description.Size = new System.Drawing.Size(200, 21);
            this.cmb_description.TabIndex = 44;
            // 
            // txt_personneimplique
            // 
            this.txt_personneimplique.Location = new System.Drawing.Point(192, 248);
            this.txt_personneimplique.Multiline = true;
            this.txt_personneimplique.Name = "txt_personneimplique";
            this.txt_personneimplique.Size = new System.Drawing.Size(200, 124);
            this.txt_personneimplique.TabIndex = 43;
            // 
            // txt_emplacement
            // 
            this.txt_emplacement.Location = new System.Drawing.Point(192, 222);
            this.txt_emplacement.Name = "txt_emplacement";
            this.txt_emplacement.Size = new System.Drawing.Size(200, 20);
            this.txt_emplacement.TabIndex = 42;
            // 
            // txt_tolerance
            // 
            this.txt_tolerance.Location = new System.Drawing.Point(192, 196);
            this.txt_tolerance.Name = "txt_tolerance";
            this.txt_tolerance.Size = new System.Drawing.Size(200, 20);
            this.txt_tolerance.TabIndex = 41;
            // 
            // txt_nomtache
            // 
            this.txt_nomtache.Location = new System.Drawing.Point(192, 118);
            this.txt_nomtache.Name = "txt_nomtache";
            this.txt_nomtache.Size = new System.Drawing.Size(200, 20);
            this.txt_nomtache.TabIndex = 40;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 405);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 39;
            this.label8.Text = "Type";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 378);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 38;
            this.label7.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 13);
            this.label6.TabIndex = 37;
            this.label6.Text = "Personne(s) impliqué(s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "Emplacement";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "Tolérance";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Date de fin";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(44, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 33;
            this.label9.Text = "Date début";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(44, 125);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 32;
            this.label10.Text = "Nom de la tâche";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(200, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 13);
            this.label11.TabIndex = 50;
            this.label11.Text = "----- Planing du conjoint -----";
            // 
            // AjoutConjoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 455);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.bt_ajouttache);
            this.Controls.Add(this.bt_enregister);
            this.Controls.Add(this.cmb_type);
            this.Controls.Add(this.cmb_description);
            this.Controls.Add(this.txt_personneimplique);
            this.Controls.Add(this.txt_emplacement);
            this.Controls.Add(this.txt_tolerance);
            this.Controls.Add(this.txt_nomtache);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_fonction);
            this.Controls.Add(this.cmb_etatsante);
            this.Controls.Add(this.label1);
            this.Name = "AjoutConjoint";
            this.Text = "AjoutConjoint";
            this.Load += new System.EventHandler(this.AjoutConjoint_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_fonction;
        private System.Windows.Forms.ComboBox cmb_etatsante;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button bt_ajouttache;
        private System.Windows.Forms.Button bt_enregister;
        private System.Windows.Forms.ComboBox cmb_type;
        private System.Windows.Forms.ComboBox cmb_description;
        private System.Windows.Forms.TextBox txt_personneimplique;
        private System.Windows.Forms.TextBox txt_emplacement;
        private System.Windows.Forms.TextBox txt_tolerance;
        private System.Windows.Forms.TextBox txt_nomtache;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}