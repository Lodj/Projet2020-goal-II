﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Planningdujour : Form
    {
        internal static Planing pln = new Planing();
        internal Tache tch = new Tache();
        private static  int i = 0;
        public Planningdujour()
        {
            InitializeComponent();
        }

        private void bt_ajouttache_Click(object sender, EventArgs e)
        {
            Planing pl = new Planing();
            Tache ta = new Tache();
            if (i == 0)
            {
                try
                {
                    Connexion.ProjetDB.Planing.InsertOnSubmit(pl);
                    Connexion.ProjetDB.SubmitChanges();
                    pln = pl;
                }
                catch (Exception ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                i++;
            }
            else
            {
                try
                {
                    ta.Id_planing = pln.Id_planing;
                    ta.nom_tache = txt_nomtache.Text;
                    ta.date_debut = dateTimePicker1.Value;
                    ta.date_fin = dateTimePicker2.Value;
                    ta.duree_tolerance = txt_tolerance.Text;
                    ta.emplacement = txt_emplacement.Text;
                    ta.personnes_impliques = txt_personneimplique.Text;
                    ta.description = cmb_description.Text;
                    ta.type_tache = cmb_type.Text;
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Tache enrégistré avec succé.");
                    tch = ta;
                    txt_nomtache.Text = "";
                    txt_tolerance.Text = "";
                    txt_emplacement.Text = "";
                    txt_personneimplique.Text = "";
                    cmb_description.Text = "";
                    cmb_type.Text = "";
                }
                catch (Exception exe)
                {
                    MessageBox.Show(exe.Message);
                }
            }
        }

        private void bt_enregister_Click(object sender, EventArgs e)
        {
            Planing pl = new Planing();
            Tache ta = new Tache();
            if (i == 0)
            {
                try
                {
                    UserCible c = new UserCible();
                    Connexion.ProjetDB.UserCible.InsertOnSubmit(c);
                    Connexion.ProjetDB.SubmitChanges();
                    pl.Id_usercreator = c.Id_usercible;
                    Connexion.ProjetDB.Planing.InsertOnSubmit(pl);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                i++;
                pln = pl;
            }
            else
            {
                ta.Id_planing = pln.Id_planing;
                ta.nom_tache = txt_nomtache.Text;
                ta.date_debut = dateTimePicker1.Value;
                ta.date_fin = dateTimePicker2.Value;
                ta.duree_tolerance = txt_tolerance.Text;
                ta.emplacement = txt_emplacement.Text;
                ta.personnes_impliques = txt_personneimplique.Text;
                ta.description = cmb_description.Text;
                ta.type_tache = cmb_type.Text;
                try
                {
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Planing enrégistré avec succé.");
                    this.Close();
                    tch = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }
        }        

        private void Planningdujour_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void cmb_type_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmb_description_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txt_personneimplique_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_emplacement_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_tolerance_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_nomtache_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
