﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Inscription : Form
    {
        internal static Utilisateur user = new Utilisateur();
        internal static UserCible us = new UserCible();
        public Inscription()
        {
            InitializeComponent();
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Inscription_Load(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void bt_enregistrer_Click(object sender, EventArgs e)
        {
            Boolean verif = true;
            if (txt_login01.Text == "")
            {
                label13.Visible = true;
                verif = false;
            }
            if (txt_prenom.Text == "")
            {
                label14.Visible = true;
                verif = false;
            }
            if (txt_nom.Text == "")
            {
                label15.Visible = true;
                verif = false;
            }
         
            if (!rd_masculin.Checked && !rd_feminin.Checked)
            {
                label17.Visible = true;
                verif = false;
            }
            if (txt_fonction01.Text == "")
            {
                label18.Visible = true;
                verif = false;
            }
            if (txt_mail.Text == "")
            {
                label19.Visible = true;
                verif = false;
            }
            if (txt_adresse.Text == "")
            {
                label20.Visible = true;
                verif = false;
            }
            if (!rd_marie.Checked && !rd_celibataire.Checked)
            {
                label21.Visible = true;
                verif = false;
            }
            
            if (rd_marie.Checked)
            {
                label22.Visible = true;
            }
            
             
            if (!rd_vivantavecparent.Checked && !rd_nevinantpasavecparent.Checked)
            {
                label23.Visible = true;
                verif = true;
            }
           
            if (txt_motdepasse.Text == "")
            {
                label24.Visible = true;
                verif = true;
            }
            
            //Remplissage du LINQ; de notre base de données
            if (verif == true)
            {
                Utilisateur u = new Utilisateur();
                try
                {
                    //Utilisateur u = new Utilisateur();
                    u.login = txt_login01.Text;
                    u.password = txt_motdepasse.Text;
                    u.nom = txt_nom.Text;
                    u.prenom = txt_prenom.Text;
                    u.date_naiss = dtp_datenaiss.Value;
                    if (rd_masculin.Checked == true)
                        u.genre = "Masculin";
                    else
                        u.genre = "Feminin";
                    u.fonction = txt_fonction01.Text;
                    u.mail = txt_mail.Text;
                    u.adress = txt_adresse.Text;
                    if (rd_celibataire.Checked == true)
                        u.etat_civil = "Celibataire";
                    else
                        u.etat_civil = "Marie";
                    u.nbre_enfant = int.Parse(txt_nbreenfant.Text);
                    /*
                     * Planningdujour p = new Planningdujour();
                    p.Text = "Remplir votre planing";
                    p.Show();
                    this.Close();
                    u.Id_planing = Planningdujour.pln.Id_planing;
                    if (rd_marie.Checked == true)
                    {
                        Informationsconjoint info = new Informationsconjoint();
                        info.Show();
                        u.Id_conjoint = Informationsconjoint.cjt.Id_conjoint;
                        if (int.Parse(txt_nbreenfant.Text) > 0)
                        { 
                            InformationEnfantParent inf = new InformationEnfantParent();
                            inf.Show();
                            u.Id_parent = InformationEnfantParent.par.Id_parent;
                        }
                    }
                    */
                    Connexion.ProjetDB.Utilisateur.InsertOnSubmit(u);
                    Connexion.ProjetDB.SubmitChanges();
                    //MessageBox.Show("Utilisateur ajouté avec succés.");
                    user = u;
                    //UserCible us = new UserCible();
                    us.Id_user = u.Id_user;
                    Connexion.ProjetDB.UserCible.InsertOnSubmit(us);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Utilisateur ajouté avec succés.");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void rd_marie_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_marie.Checked)
            {
                label9.Visible = true;
                txt_nbreenfant.Visible = true;
               // label22.Visible = true;
            }
        }

        private void rd_celibataire_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_celibataire.Checked)
            {
                label9.Visible = false;
                txt_nbreenfant.Visible = false;
                label22.Visible = false;
            }
        }

        private void txt_motdepasse_TextChanged(object sender, EventArgs e)
        {
            txt_motdepasse.UseSystemPasswordChar = true;
        }
    }
}
