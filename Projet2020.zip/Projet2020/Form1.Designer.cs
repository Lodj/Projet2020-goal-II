﻿namespace Projet2020
{
    partial class Connexion
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_login = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.bt_submit1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bt_creercompte = new System.Windows.Forms.Button();
            this.bt_twitter = new System.Windows.Forms.Button();
            this.bt_google = new System.Windows.Forms.Button();
            this.bt_facebook = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(267, 200);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(267, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Login";
            // 
            // txt_login
            // 
            this.txt_login.Location = new System.Drawing.Point(326, 153);
            this.txt_login.Name = "txt_login";
            this.txt_login.Size = new System.Drawing.Size(100, 20);
            this.txt_login.TabIndex = 13;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(326, 193);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(100, 20);
            this.txt_password.TabIndex = 14;
            // 
            // bt_submit1
            // 
            this.bt_submit1.Location = new System.Drawing.Point(326, 270);
            this.bt_submit1.Name = "bt_submit1";
            this.bt_submit1.Size = new System.Drawing.Size(100, 34);
            this.bt_submit1.TabIndex = 15;
            this.bt_submit1.Text = "Submit";
            this.bt_submit1.UseVisualStyleBackColor = true;
            this.bt_submit1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(344, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Connexion";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(347, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "------ Ou ------";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(267, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(241, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Connectez-vous avec votre login et mot de passe";
            // 
            // bt_creercompte
            // 
            this.bt_creercompte.Location = new System.Drawing.Point(326, 320);
            this.bt_creercompte.Name = "bt_creercompte";
            this.bt_creercompte.Size = new System.Drawing.Size(100, 33);
            this.bt_creercompte.TabIndex = 21;
            this.bt_creercompte.Text = "Créer un compte";
            this.bt_creercompte.UseVisualStyleBackColor = true;
            this.bt_creercompte.Click += new System.EventHandler(this.bt_creercompte_Click);
            // 
            // bt_twitter
            // 
            this.bt_twitter.Image = global::Projet2020.Properties.Resources.twitter;
            this.bt_twitter.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bt_twitter.Location = new System.Drawing.Point(440, 52);
            this.bt_twitter.Name = "bt_twitter";
            this.bt_twitter.Size = new System.Drawing.Size(107, 35);
            this.bt_twitter.TabIndex = 23;
            this.bt_twitter.Text = "Twitter";
            this.bt_twitter.UseVisualStyleBackColor = true;
            // 
            // bt_google
            // 
            this.bt_google.Image = global::Projet2020.Properties.Resources.Google1;
            this.bt_google.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bt_google.Location = new System.Drawing.Point(327, 52);
            this.bt_google.Name = "bt_google";
            this.bt_google.Size = new System.Drawing.Size(107, 35);
            this.bt_google.TabIndex = 18;
            this.bt_google.Text = "Google";
            this.bt_google.UseVisualStyleBackColor = true;
            // 
            // bt_facebook
            // 
            this.bt_facebook.Image = global::Projet2020.Properties.Resources.facebbok2;
            this.bt_facebook.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bt_facebook.Location = new System.Drawing.Point(206, 52);
            this.bt_facebook.Name = "bt_facebook";
            this.bt_facebook.Size = new System.Drawing.Size(114, 35);
            this.bt_facebook.TabIndex = 17;
            this.bt_facebook.Text = "Facebook";
            this.bt_facebook.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(327, 219);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(128, 17);
            this.checkBox1.TabIndex = 24;
            this.checkBox1.Text = "Afficher mot de passe";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(327, 243);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(102, 13);
            this.linkLabel1.TabIndex = 25;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Mot de passe oublié";
            // 
            // Connexion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Projet2020.Properties.Resources.Gestion_de_temps1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 416);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.bt_twitter);
            this.Controls.Add(this.bt_creercompte);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bt_google);
            this.Controls.Add(this.bt_facebook);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.bt_submit1);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_login);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Connexion";
            this.Text = "Connexion";
            this.Load += new System.EventHandler(this.Connexion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_login;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button bt_submit1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_facebook;
        private System.Windows.Forms.Button bt_google;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bt_creercompte;
        private System.Windows.Forms.Button bt_twitter;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}

