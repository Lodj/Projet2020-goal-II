﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Connexion : Form
    {
        internal static ProjetDBDataContext ProjetDB = new ProjetDBDataContext();
        //public static UserCible cible = new UserCible();
        public Connexion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 ac = new Form2();
            ac.Show();
            this.Hide();
        }

        private void Connexion_Load(object sender, EventArgs e)
        {

        }

        private void bt_creercompte_Click(object sender, EventArgs e)
        {
            Inscription ins = new Inscription();
            ins.ShowDialog();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                txt_password.UseSystemPasswordChar = false;
            else
                txt_password.UseSystemPasswordChar = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Informationsconjoint info = new Informationsconjoint();
            info.Show();
            this.Hide();
        }
    }
}
