﻿namespace Projet2020
{
    partial class Inscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_prenom = new System.Windows.Forms.TextBox();
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.txt_fonction01 = new System.Windows.Forms.TextBox();
            this.dtp_datenaiss = new System.Windows.Forms.DateTimePicker();
            this.rd_masculin = new System.Windows.Forms.RadioButton();
            this.txt_adresse = new System.Windows.Forms.TextBox();
            this.rd_marie = new System.Windows.Forms.RadioButton();
            this.txt_nbreenfant = new System.Windows.Forms.TextBox();
            this.rd_vivantavecparent = new System.Windows.Forms.RadioButton();
            this.bt_enregistrer = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_login01 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_motdepasse = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rd_feminin = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rd_celibataire = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rd_nevinantpasavecparent = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(120, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Prénom";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(120, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nom";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(120, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date de naissance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Genre";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(120, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Fonction";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(120, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Adresse mail";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(123, 236);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Adresse";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(120, 274);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Etat Civil";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(120, 308);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Nombre d\'enfant(s)";
            this.label9.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(120, 339);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Vivant avec tes parents";
            // 
            // txt_prenom
            // 
            this.txt_prenom.Location = new System.Drawing.Point(246, 42);
            this.txt_prenom.Name = "txt_prenom";
            this.txt_prenom.Size = new System.Drawing.Size(199, 20);
            this.txt_prenom.TabIndex = 10;
            this.txt_prenom.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt_nom
            // 
            this.txt_nom.Location = new System.Drawing.Point(247, 68);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(199, 20);
            this.txt_nom.TabIndex = 11;
            // 
            // txt_mail
            // 
            this.txt_mail.Location = new System.Drawing.Point(245, 203);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(200, 20);
            this.txt_mail.TabIndex = 13;
            this.txt_mail.Text = "ibrahimadiallo971@hotmail.com";
            // 
            // txt_fonction01
            // 
            this.txt_fonction01.Location = new System.Drawing.Point(246, 177);
            this.txt_fonction01.Name = "txt_fonction01";
            this.txt_fonction01.Size = new System.Drawing.Size(199, 20);
            this.txt_fonction01.TabIndex = 14;
            // 
            // dtp_datenaiss
            // 
            this.dtp_datenaiss.Location = new System.Drawing.Point(246, 96);
            this.dtp_datenaiss.Name = "dtp_datenaiss";
            this.dtp_datenaiss.Size = new System.Drawing.Size(200, 20);
            this.dtp_datenaiss.TabIndex = 15;
            // 
            // rd_masculin
            // 
            this.rd_masculin.AutoSize = true;
            this.rd_masculin.Location = new System.Drawing.Point(6, 19);
            this.rd_masculin.Name = "rd_masculin";
            this.rd_masculin.Size = new System.Drawing.Size(67, 17);
            this.rd_masculin.TabIndex = 16;
            this.rd_masculin.TabStop = true;
            this.rd_masculin.Text = "Masculin";
            this.rd_masculin.UseVisualStyleBackColor = true;
            // 
            // txt_adresse
            // 
            this.txt_adresse.Location = new System.Drawing.Point(246, 229);
            this.txt_adresse.Name = "txt_adresse";
            this.txt_adresse.Size = new System.Drawing.Size(199, 20);
            this.txt_adresse.TabIndex = 18;
            // 
            // rd_marie
            // 
            this.rd_marie.AutoSize = true;
            this.rd_marie.Location = new System.Drawing.Point(6, 17);
            this.rd_marie.Name = "rd_marie";
            this.rd_marie.Size = new System.Drawing.Size(51, 17);
            this.rd_marie.TabIndex = 19;
            this.rd_marie.TabStop = true;
            this.rd_marie.Text = "Marié";
            this.rd_marie.UseVisualStyleBackColor = true;
            this.rd_marie.CheckedChanged += new System.EventHandler(this.rd_marie_CheckedChanged);
            // 
            // txt_nbreenfant
            // 
            this.txt_nbreenfant.Location = new System.Drawing.Point(246, 301);
            this.txt_nbreenfant.Name = "txt_nbreenfant";
            this.txt_nbreenfant.Size = new System.Drawing.Size(199, 20);
            this.txt_nbreenfant.TabIndex = 21;
            this.txt_nbreenfant.Visible = false;
            // 
            // rd_vivantavecparent
            // 
            this.rd_vivantavecparent.AutoSize = true;
            this.rd_vivantavecparent.Location = new System.Drawing.Point(6, 17);
            this.rd_vivantavecparent.Name = "rd_vivantavecparent";
            this.rd_vivantavecparent.Size = new System.Drawing.Size(41, 17);
            this.rd_vivantavecparent.TabIndex = 22;
            this.rd_vivantavecparent.TabStop = true;
            this.rd_vivantavecparent.Text = "Oui";
            this.rd_vivantavecparent.UseVisualStyleBackColor = true;
            // 
            // bt_enregistrer
            // 
            this.bt_enregistrer.Location = new System.Drawing.Point(302, 403);
            this.bt_enregistrer.Name = "bt_enregistrer";
            this.bt_enregistrer.Size = new System.Drawing.Size(75, 23);
            this.bt_enregistrer.TabIndex = 24;
            this.bt_enregistrer.Text = "Enrégistrer";
            this.bt_enregistrer.UseVisualStyleBackColor = true;
            this.bt_enregistrer.Click += new System.EventHandler(this.bt_enregistrer_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(120, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "Login";
            // 
            // txt_login01
            // 
            this.txt_login01.Location = new System.Drawing.Point(246, 15);
            this.txt_login01.Name = "txt_login01";
            this.txt_login01.Size = new System.Drawing.Size(199, 20);
            this.txt_login01.TabIndex = 26;
            this.txt_login01.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(120, 375);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "Mot de passe";
            // 
            // txt_motdepasse
            // 
            this.txt_motdepasse.Location = new System.Drawing.Point(246, 366);
            this.txt_motdepasse.Name = "txt_motdepasse";
            this.txt_motdepasse.Size = new System.Drawing.Size(199, 20);
            this.txt_motdepasse.TabIndex = 28;
            this.txt_motdepasse.TextChanged += new System.EventHandler(this.txt_motdepasse_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.DarkRed;
            this.label13.Location = new System.Drawing.Point(496, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 13);
            this.label13.TabIndex = 29;
            this.label13.Text = "*Saisir login";
            this.label13.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.DarkRed;
            this.label14.Location = new System.Drawing.Point(496, 49);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = "*Saisir prénom";
            this.label14.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.DarkRed;
            this.label15.Location = new System.Drawing.Point(496, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 13);
            this.label15.TabIndex = 31;
            this.label15.Text = "*Saisir nom";
            this.label15.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.DarkRed;
            this.label16.Location = new System.Drawing.Point(496, 103);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "*Saisir date de naissance";
            this.label16.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.DarkRed;
            this.label17.Location = new System.Drawing.Point(496, 152);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 13);
            this.label17.TabIndex = 33;
            this.label17.Text = "*Saisir genre";
            this.label17.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.DarkRed;
            this.label18.Location = new System.Drawing.Point(498, 184);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 13);
            this.label18.TabIndex = 34;
            this.label18.Text = "*Saisir votre fonction";
            this.label18.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.DarkRed;
            this.label19.Location = new System.Drawing.Point(496, 210);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 13);
            this.label19.TabIndex = 35;
            this.label19.Text = "*Saisir adresse mail";
            this.label19.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.DarkRed;
            this.label20.Location = new System.Drawing.Point(496, 236);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(103, 13);
            this.label20.TabIndex = 36;
            this.label20.Text = "*Saisir votre adresse";
            this.label20.Visible = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.DarkRed;
            this.label21.Location = new System.Drawing.Point(495, 274);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(105, 13);
            this.label21.TabIndex = 37;
            this.label21.Text = "*Saisir votre etat civil";
            this.label21.Visible = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.DarkRed;
            this.label22.Location = new System.Drawing.Point(496, 308);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(156, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "*Combien d\'enfants avez-vous?";
            this.label22.Visible = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.DarkRed;
            this.label23.Location = new System.Drawing.Point(496, 341);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(156, 13);
            this.label23.TabIndex = 39;
            this.label23.Text = "*Viviez-vous avec vos parents?";
            this.label23.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.DarkRed;
            this.label24.Location = new System.Drawing.Point(496, 375);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(102, 13);
            this.label24.TabIndex = 40;
            this.label24.Text = "*Saisir mot de passe";
            this.label24.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rd_feminin);
            this.groupBox1.Controls.Add(this.rd_masculin);
            this.groupBox1.Location = new System.Drawing.Point(246, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(199, 40);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            // 
            // rd_feminin
            // 
            this.rd_feminin.AutoSize = true;
            this.rd_feminin.Location = new System.Drawing.Point(120, 17);
            this.rd_feminin.Name = "rd_feminin";
            this.rd_feminin.Size = new System.Drawing.Size(61, 17);
            this.rd_feminin.TabIndex = 18;
            this.rd_feminin.TabStop = true;
            this.rd_feminin.Text = "Féminin";
            this.rd_feminin.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rd_celibataire);
            this.groupBox3.Controls.Add(this.rd_marie);
            this.groupBox3.Location = new System.Drawing.Point(245, 255);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 40);
            this.groupBox3.TabIndex = 46;
            this.groupBox3.TabStop = false;
            // 
            // rd_celibataire
            // 
            this.rd_celibataire.AutoSize = true;
            this.rd_celibataire.Location = new System.Drawing.Point(120, 17);
            this.rd_celibataire.Name = "rd_celibataire";
            this.rd_celibataire.Size = new System.Drawing.Size(74, 17);
            this.rd_celibataire.TabIndex = 21;
            this.rd_celibataire.TabStop = true;
            this.rd_celibataire.Text = "Célibataire";
            this.rd_celibataire.UseVisualStyleBackColor = true;
            this.rd_celibataire.CheckedChanged += new System.EventHandler(this.rd_celibataire_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rd_nevinantpasavecparent);
            this.groupBox5.Controls.Add(this.rd_vivantavecparent);
            this.groupBox5.Location = new System.Drawing.Point(245, 320);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 40);
            this.groupBox5.TabIndex = 47;
            this.groupBox5.TabStop = false;
            // 
            // rd_nevinantpasavecparent
            // 
            this.rd_nevinantpasavecparent.AutoSize = true;
            this.rd_nevinantpasavecparent.Location = new System.Drawing.Point(120, 17);
            this.rd_nevinantpasavecparent.Name = "rd_nevinantpasavecparent";
            this.rd_nevinantpasavecparent.Size = new System.Drawing.Size(45, 17);
            this.rd_nevinantpasavecparent.TabIndex = 24;
            this.rd_nevinantpasavecparent.TabStop = true;
            this.rd_nevinantpasavecparent.Text = "Non";
            this.rd_nevinantpasavecparent.UseVisualStyleBackColor = true;
            // 
            // Inscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 450);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_motdepasse);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_login01);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.bt_enregistrer);
            this.Controls.Add(this.txt_nbreenfant);
            this.Controls.Add(this.txt_adresse);
            this.Controls.Add(this.dtp_datenaiss);
            this.Controls.Add(this.txt_fonction01);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.txt_nom);
            this.Controls.Add(this.txt_prenom);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Inscription";
            this.Text = "Inscription";
            this.Load += new System.EventHandler(this.Inscription_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_prenom;
        private System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.TextBox txt_fonction01;
        private System.Windows.Forms.DateTimePicker dtp_datenaiss;
        private System.Windows.Forms.RadioButton rd_masculin;
        private System.Windows.Forms.TextBox txt_adresse;
        private System.Windows.Forms.RadioButton rd_marie;
        private System.Windows.Forms.TextBox txt_nbreenfant;
        private System.Windows.Forms.RadioButton rd_vivantavecparent;
        private System.Windows.Forms.Button bt_enregistrer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_login01;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_motdepasse;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rd_feminin;
        private System.Windows.Forms.RadioButton rd_celibataire;
        private System.Windows.Forms.RadioButton rd_nevinantpasavecparent;
    }
}