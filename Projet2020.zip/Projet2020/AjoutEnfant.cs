﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class AjoutEnfant : Form
    {
        private static Planing pp = new Planing();
        private static Tache tac = new Tache();
        private static int i = 0;
        public AjoutEnfant()
        {
            InitializeComponent();
        }

        private void AjoutEnfant_Load(object sender, EventArgs e)
        {

        }

        private void bt_enregister_Click(object sender, EventArgs e)
        {
            Enfant en = new Enfant();
            UserCible u = new UserCible();
            Planing pl = new Planing();
            Tache ta = new Tache();
            if (i == 0)
            {
                try
                {
                    en.niveau_etude = cmb_niveau.Text;
                    en.nom_ecole = txt_nomecole.Text;
                    en.distance_ecole_maison = float.Parse(txt_distance.Text);
                    Connexion.ProjetDB.Enfant.InsertOnSubmit(en);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e02)
                {
                    MessageBox.Show(e02.Message);
                }
                try
                {
                    u.Id_enfant = en.Id_enfant;
                    Connexion.ProjetDB.UserCible.InsertOnSubmit(u);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e03)
                {
                    MessageBox.Show(e03.Message);
                }
                try
                {
                    pl.Id_usercreator = u.Id_usercible;
                    Connexion.ProjetDB.Planing.InsertOnSubmit(pl);
                    Connexion.ProjetDB.SubmitChanges();
                    //MessageBox.Show("Planing enrégistré avec succé.");
                }
                catch (Exception ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                try
                {
                    ta.Id_planing = pl.Id_planing;
                    ta.nom_tache = txt_nomtache.Text;
                    ta.date_debut = dateTimePicker1.Value;
                    ta.date_fin = dateTimePicker2.Value;
                    ta.duree_tolerance = txt_tolerance.Text;
                    ta.emplacement = txt_emplacement.Text;
                    ta.personnes_impliques = txt_personneimplique.Text;
                    ta.description = cmb_description.Text;
                    ta.type_tache = cmb_type.Text;
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Planing enrégistré avec succé.");
                    tac = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
                i++;
                pp = pl;
                this.Close();
            }
            else
            {
                try
                {
                    ta.Id_planing = pp.Id_planing;
                    ta.nom_tache = txt_nomtache.Text;
                    ta.date_debut = dateTimePicker1.Value;
                    ta.date_fin = dateTimePicker2.Value;
                    ta.duree_tolerance = txt_tolerance.Text;
                    ta.emplacement = txt_emplacement.Text;
                    ta.personnes_impliques = txt_personneimplique.Text;
                    ta.description = cmb_description.Text;
                    ta.type_tache = cmb_type.Text;
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Planing enrégistré avec succé.");
                    tac = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
                this.Close();
            }
        }

        private void bt_ajouttache_Click(object sender, EventArgs e)
        {
            Enfant en = new Enfant();
            UserCible u = new UserCible();
            Planing pl = new Planing();
            Tache ta = new Tache();
            if (i == 0)
            {
                try
                {
                    en.niveau_etude = cmb_niveau.Text;
                    en.nom_ecole = txt_nomecole.Text;
                    en.distance_ecole_maison = float.Parse(txt_distance.Text);
                    Connexion.ProjetDB.Enfant.InsertOnSubmit(en);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e02)
                {
                    MessageBox.Show(e02.Message);
                }
                try
                {
                    u.Id_enfant = en.Id_enfant;
                    Connexion.ProjetDB.UserCible.InsertOnSubmit(u);
                    Connexion.ProjetDB.SubmitChanges();
                }
                catch (Exception e03)
                {
                    MessageBox.Show(e03.Message);
                }
                try
                {
                    pl.Id_usercreator = u.Id_usercible;
                    Connexion.ProjetDB.Planing.InsertOnSubmit(pl);
                    Connexion.ProjetDB.SubmitChanges();
                    //MessageBox.Show("Tache enrégistré avec succé.");
                }
                catch (Exception ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                try
                {
                    ta.Id_planing = pl.Id_planing;
                    ta.nom_tache = txt_nomtache.Text;
                    ta.date_debut = dateTimePicker1.Value;
                    ta.date_fin = dateTimePicker2.Value;
                    ta.duree_tolerance = txt_tolerance.Text;
                    ta.emplacement = txt_emplacement.Text;
                    ta.personnes_impliques = txt_personneimplique.Text;
                    ta.description = cmb_description.Text;
                    ta.type_tache = cmb_type.Text;
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Tache enrégistré avec succé.");
                    tac = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
                txt_nomtache.Text = "";
                txt_tolerance.Text = "";
                txt_emplacement.Text = "";
                txt_personneimplique.Text = "";
                cmb_description.Text = "";
                cmb_type.Text = "";
                i++;
                pp = pl;
                //this.Close();
            }
            else
            {
                try
                {
                    ta.Id_planing = pp.Id_planing;
                    ta.nom_tache = txt_nomtache.Text;
                    ta.date_debut = dateTimePicker1.Value;
                    ta.date_fin = dateTimePicker2.Value;
                    ta.duree_tolerance = txt_tolerance.Text;
                    ta.emplacement = txt_emplacement.Text;
                    ta.personnes_impliques = txt_personneimplique.Text;
                    ta.description = cmb_description.Text;
                    ta.type_tache = cmb_type.Text;
                    Connexion.ProjetDB.Tache.InsertOnSubmit(ta);
                    //Connexion.ProjetDB.Planings.InsertOnSubmit(pln);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Tache enrégistré avec succé.");
                    tac = ta;
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
                txt_nomtache.Text = "";
                txt_tolerance.Text = "";
                txt_emplacement.Text = "";
                txt_personneimplique.Text = "";
                cmb_description.Text = "";
                cmb_type.Text = "";
                //this.Close();
            }
        }
    }
}
