﻿namespace Projet2020
{
    partial class Informationsconjoint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_planingconjoint = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_etatsante = new System.Windows.Forms.ComboBox();
            this.txt_fonction = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_planingconjoint
            // 
            this.bt_planingconjoint.Location = new System.Drawing.Point(341, 155);
            this.bt_planingconjoint.Name = "bt_planingconjoint";
            this.bt_planingconjoint.Size = new System.Drawing.Size(199, 23);
            this.bt_planingconjoint.TabIndex = 0;
            this.bt_planingconjoint.Text = "Remplir le Planning ";
            this.bt_planingconjoint.UseVisualStyleBackColor = true;
            this.bt_planingconjoint.Click += new System.EventHandler(this.bt_planingconjoint_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(192, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Etat de santé du conjoint";
            // 
            // cmb_etatsante
            // 
            this.cmb_etatsante.FormattingEnabled = true;
            this.cmb_etatsante.Items.AddRange(new object[] {
            "Sain et sauve",
            "En forme",
            "Un peu malade",
            "Pas totalement en forme",
            "Malade",
            "Très malade"});
            this.cmb_etatsante.Location = new System.Drawing.Point(341, 74);
            this.cmb_etatsante.Name = "cmb_etatsante";
            this.cmb_etatsante.Size = new System.Drawing.Size(199, 21);
            this.cmb_etatsante.TabIndex = 2;
            // 
            // txt_fonction
            // 
            this.txt_fonction.Location = new System.Drawing.Point(341, 114);
            this.txt_fonction.Name = "txt_fonction";
            this.txt_fonction.Size = new System.Drawing.Size(199, 20);
            this.txt_fonction.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Fonction du conjoint";
            // 
            // Informationsconjoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Projet2020.Properties.Resources.conjoint;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_fonction);
            this.Controls.Add(this.cmb_etatsante);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_planingconjoint);
            this.Name = "Informationsconjoint";
            this.Text = "Informationsconjoint";
            this.Load += new System.EventHandler(this.Informationsconjoint_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_planingconjoint;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmb_etatsante;
        private System.Windows.Forms.TextBox txt_fonction;
        private System.Windows.Forms.Label label2;
    }
}