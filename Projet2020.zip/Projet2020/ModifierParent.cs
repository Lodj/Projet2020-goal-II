﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class ModifierParent : Form
    {
        public ModifierParent()
        {
            InitializeComponent();
        }

        private void ModifierParent_Load(object sender, EventArgs e)
        {
            /*foreach (Control x in groupBox1.Controls)
            {
                if (!(x is Label || x is Button))
                    x.Enabled = false;
            }
            textBox1.Enabled = true;
            */
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Parent p = Connexion.ProjetDB.Parent.Single<Parent>(x => x.Id_parent == int.Parse(textBox1.Text));
                if (p == null)
                {
                    throw new Exception("Veuillez vérifier l'identifiant: parent n'existe pas.");
                }
                else
                {
                    foreach (Control x in groupBox1.Controls)
                    {
                        if (!(x is Label || x is Button))
                            x.Enabled = true;
                    }
                    var lst2 = from x in Connexion.ProjetDB.UserCible
                               where x.Id_parent == int.Parse(textBox1.Text)
                               select x;
                    UserCible us = lst2.First<UserCible>(x => x.Id_parent == int.Parse(textBox1.Text));
                    var lst1 = from y in Connexion.ProjetDB.Planing
                               where y.Id_usercreator==us.Id_usercible
                               select y;
                    Planing pl = lst1.First<Planing>(x => x.Id_usercreator == us.Id_usercible);
                    var lst0 = from z in Connexion.ProjetDB.Tache
                               join z1 in lst1
                               on z.Id_planing equals z1.Id_planing
                               select z;
                    Tache t = lst0.First<Tache>(x => x.Id_planing == pl.Id_planing);
                    t.nom_tache = txt_nomtache.Text;
                    t.date_debut = dateTimePicker1.Value;
                    t.date_fin = dateTimePicker2.Value;
                    t.duree_tolerance = txt_tolerance.Text;
                    t.emplacement = txt_emplacement.Text;
                    t.personnes_impliques = txt_personneimplique.Text;
                    t.description = cmb_description.Text;
                    t.type_tache = cmb_type.Text;
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Modificaion éffectuée avec succé.");

                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }
    }
}
