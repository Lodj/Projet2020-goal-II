﻿namespace Projet2020
{
    partial class AjoutParent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bt_ajouttache = new System.Windows.Forms.Button();
            this.bt_enregister = new System.Windows.Forms.Button();
            this.cmb_type = new System.Windows.Forms.ComboBox();
            this.cmb_description = new System.Windows.Forms.ComboBox();
            this.txt_personneimplique = new System.Windows.Forms.TextBox();
            this.txt_emplacement = new System.Windows.Forms.TextBox();
            this.txt_tolerance = new System.Windows.Forms.TextBox();
            this.txt_nomtache = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(190, 79);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 49;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(190, 53);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 48;
            // 
            // bt_ajouttache
            // 
            this.bt_ajouttache.Location = new System.Drawing.Point(245, 366);
            this.bt_ajouttache.Name = "bt_ajouttache";
            this.bt_ajouttache.Size = new System.Drawing.Size(145, 23);
            this.bt_ajouttache.TabIndex = 47;
            this.bt_ajouttache.Text = "Ajoter une autre tache";
            this.bt_ajouttache.UseVisualStyleBackColor = true;
            this.bt_ajouttache.Click += new System.EventHandler(this.bt_ajouttache_Click);
            // 
            // bt_enregister
            // 
            this.bt_enregister.Location = new System.Drawing.Point(132, 366);
            this.bt_enregister.Name = "bt_enregister";
            this.bt_enregister.Size = new System.Drawing.Size(75, 23);
            this.bt_enregister.TabIndex = 46;
            this.bt_enregister.Text = "Enrégistrer";
            this.bt_enregister.UseVisualStyleBackColor = true;
            this.bt_enregister.Click += new System.EventHandler(this.bt_enregister_Click);
            // 
            // cmb_type
            // 
            this.cmb_type.FormattingEnabled = true;
            this.cmb_type.Items.AddRange(new object[] {
            "Normale",
            "Urgente",
            "Habituelle",
            "Inhabituelle"});
            this.cmb_type.Location = new System.Drawing.Point(190, 314);
            this.cmb_type.Name = "cmb_type";
            this.cmb_type.Size = new System.Drawing.Size(200, 21);
            this.cmb_type.TabIndex = 45;
            // 
            // cmb_description
            // 
            this.cmb_description.FormattingEnabled = true;
            this.cmb_description.Items.AddRange(new object[] {
            "Non important",
            "Important",
            "Très important"});
            this.cmb_description.Location = new System.Drawing.Point(190, 287);
            this.cmb_description.Name = "cmb_description";
            this.cmb_description.Size = new System.Drawing.Size(200, 21);
            this.cmb_description.TabIndex = 44;
            // 
            // txt_personneimplique
            // 
            this.txt_personneimplique.Location = new System.Drawing.Point(190, 157);
            this.txt_personneimplique.Multiline = true;
            this.txt_personneimplique.Name = "txt_personneimplique";
            this.txt_personneimplique.Size = new System.Drawing.Size(200, 124);
            this.txt_personneimplique.TabIndex = 43;
            // 
            // txt_emplacement
            // 
            this.txt_emplacement.Location = new System.Drawing.Point(190, 131);
            this.txt_emplacement.Name = "txt_emplacement";
            this.txt_emplacement.Size = new System.Drawing.Size(200, 20);
            this.txt_emplacement.TabIndex = 42;
            // 
            // txt_tolerance
            // 
            this.txt_tolerance.Location = new System.Drawing.Point(190, 105);
            this.txt_tolerance.Name = "txt_tolerance";
            this.txt_tolerance.Size = new System.Drawing.Size(200, 20);
            this.txt_tolerance.TabIndex = 41;
            // 
            // txt_nomtache
            // 
            this.txt_nomtache.Location = new System.Drawing.Point(190, 27);
            this.txt_nomtache.Name = "txt_nomtache";
            this.txt_nomtache.Size = new System.Drawing.Size(200, 20);
            this.txt_nomtache.TabIndex = 40;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(61, 322);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 39;
            this.label8.Text = "Type";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(61, 295);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 38;
            this.label7.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 13);
            this.label6.TabIndex = 37;
            this.label6.Text = "Personne(s) impliqué(s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(61, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "Emplacement";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(61, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "Tolérance";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Date de fin";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Date début";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Nom de la tâche";
            // 
            // AjoutParent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Projet2020.Properties.Resources.temps;
            this.ClientSize = new System.Drawing.Size(487, 450);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.bt_ajouttache);
            this.Controls.Add(this.bt_enregister);
            this.Controls.Add(this.cmb_type);
            this.Controls.Add(this.cmb_description);
            this.Controls.Add(this.txt_personneimplique);
            this.Controls.Add(this.txt_emplacement);
            this.Controls.Add(this.txt_tolerance);
            this.Controls.Add(this.txt_nomtache);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AjoutParent";
            this.Text = "AjoutParent";
            this.Load += new System.EventHandler(this.AjoutParent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button bt_ajouttache;
        private System.Windows.Forms.Button bt_enregister;
        private System.Windows.Forms.ComboBox cmb_type;
        private System.Windows.Forms.ComboBox cmb_description;
        private System.Windows.Forms.TextBox txt_personneimplique;
        private System.Windows.Forms.TextBox txt_emplacement;
        private System.Windows.Forms.TextBox txt_tolerance;
        private System.Windows.Forms.TextBox txt_nomtache;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}