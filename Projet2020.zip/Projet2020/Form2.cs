﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void conjointToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AjoutConjoint c = new AjoutConjoint();
            c.Show();
        }

        private void monPlaningToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AjoutParent p = new AjoutParent();
            p.Show();
            this.Hide();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DeleteParent s = new DeleteParent();
            s.Show();
            this.Hide();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            ModifierParent m = new ModifierParent();
            m.Show();
        }

        private void suprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteConjoint c = new DeleteConjoint();
            c.Show();
        }

        private void modifierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModifierConjoint modif = new ModifierConjoint();
            modif.Show();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            AjoutEnfant en = new AjoutEnfant();
            en.Show();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            DeleteEnfant dl = new DeleteEnfant();
            dl.Show();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            ModifierEnfant m1 = new ModifierEnfant();
            m1.Show();
        }

        private void ajouterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AjoutPlaningUser a = new AjoutPlaningUser();
            a.Show();
        }

        private void consulterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
