﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2020
{
    public partial class DeleteEnfant : Form
    {
        public DeleteEnfant()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Enfant en = Connexion.ProjetDB.Enfant.Single<Enfant>(x => x.Id_enfant == int.Parse(textBox1.Text));
                if (en == null)
                {
                    throw new Exception("Veuillez vérifier l'identifiant: enfant n'existe pas.");
                }
                else
                {
                    var lst2 = from x in Connexion.ProjetDB.UserCible
                               where x.Id_enfant == int.Parse(textBox1.Text)
                               select x;
                    var lst1 = from y in Connexion.ProjetDB.Planing
                               join y1 in lst2
                               on y.Id_usercreator equals y1.Id_usercible
                               select y;
                    var lst0 = from z in Connexion.ProjetDB.Tache
                               join z1 in lst1
                               on z.Id_planing equals z1.Id_planing
                               select z;
                    foreach (var item0 in lst0)
                    {
                        Connexion.ProjetDB.Tache.DeleteOnSubmit(item0);
                    }
                    foreach (var item1 in lst1)
                    {
                        Connexion.ProjetDB.Planing.DeleteOnSubmit(item1);
                    }
                    var lst = from x in Connexion.ProjetDB.UserCible
                              where x.Id_enfant == int.Parse(textBox1.Text)
                              select x;
                    foreach (var item in lst)
                    {
                        //i = item.Id_usercible;
                        Connexion.ProjetDB.UserCible.DeleteOnSubmit(item);
                    }
                    Connexion.ProjetDB.Enfant.DeleteOnSubmit(en);
                    Connexion.ProjetDB.SubmitChanges();
                    MessageBox.Show("Suppression éffectuée avec succé.");
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }
    }
}
