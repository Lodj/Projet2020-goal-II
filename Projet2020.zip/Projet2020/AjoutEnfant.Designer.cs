﻿namespace Projet2020
{
    partial class AjoutEnfant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmb_niveau = new System.Windows.Forms.ComboBox();
            this.txt_nomecole = new System.Windows.Forms.TextBox();
            this.txt_distance = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bt_ajouttache = new System.Windows.Forms.Button();
            this.bt_enregister = new System.Windows.Forms.Button();
            this.cmb_type = new System.Windows.Forms.ComboBox();
            this.cmb_description = new System.Windows.Forms.ComboBox();
            this.txt_personneimplique = new System.Windows.Forms.TextBox();
            this.txt_emplacement = new System.Windows.Forms.TextBox();
            this.txt_tolerance = new System.Windows.Forms.TextBox();
            this.txt_nomtache = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmb_niveau
            // 
            this.cmb_niveau.FormattingEnabled = true;
            this.cmb_niveau.Items.AddRange(new object[] {
            "Primaire 1ère année",
            "Primaire 2ème année",
            "Primaire 3ème année",
            "Primaire 4ème année",
            "Primaire 5ème année",
            "Primaire 6ème année",
            "Moyen secondaire 1ère année",
            "Moyen secondaire 2ème année",
            "Moyen secondaire 3ème année",
            "Secondaire 1ère année",
            "Secondaire 2ème année",
            "Secondaire 3ème année",
            "Secondaire 4ème année",
            "Licence 1",
            "Licence 2",
            "Licence 3",
            "Master 1",
            "Master 2",
            "Doctorat"});
            this.cmb_niveau.Location = new System.Drawing.Point(221, 18);
            this.cmb_niveau.Name = "cmb_niveau";
            this.cmb_niveau.Size = new System.Drawing.Size(200, 21);
            this.cmb_niveau.TabIndex = 39;
            // 
            // txt_nomecole
            // 
            this.txt_nomecole.Location = new System.Drawing.Point(221, 45);
            this.txt_nomecole.Name = "txt_nomecole";
            this.txt_nomecole.Size = new System.Drawing.Size(200, 20);
            this.txt_nomecole.TabIndex = 38;
            // 
            // txt_distance
            // 
            this.txt_distance.Location = new System.Drawing.Point(221, 71);
            this.txt_distance.Name = "txt_distance";
            this.txt_distance.Size = new System.Drawing.Size(200, 20);
            this.txt_distance.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "Distance entre l\'école et la maison";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 35;
            this.label2.Text = "Nom d\'école";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 34;
            this.label1.Text = "Niveau d\'études";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(160, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 13);
            this.label11.TabIndex = 69;
            this.label11.Text = "----- Planing du conjoint -----";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(221, 191);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 68;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(221, 165);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 67;
            // 
            // bt_ajouttache
            // 
            this.bt_ajouttache.Location = new System.Drawing.Point(453, 276);
            this.bt_ajouttache.Name = "bt_ajouttache";
            this.bt_ajouttache.Size = new System.Drawing.Size(108, 73);
            this.bt_ajouttache.TabIndex = 66;
            this.bt_ajouttache.Text = "Ajoter une autre tache";
            this.bt_ajouttache.UseVisualStyleBackColor = true;
            this.bt_ajouttache.Click += new System.EventHandler(this.bt_ajouttache_Click);
            // 
            // bt_enregister
            // 
            this.bt_enregister.Location = new System.Drawing.Point(453, 165);
            this.bt_enregister.Name = "bt_enregister";
            this.bt_enregister.Size = new System.Drawing.Size(108, 72);
            this.bt_enregister.TabIndex = 65;
            this.bt_enregister.Text = "Enrégistrer";
            this.bt_enregister.UseVisualStyleBackColor = true;
            this.bt_enregister.Click += new System.EventHandler(this.bt_enregister_Click);
            // 
            // cmb_type
            // 
            this.cmb_type.FormattingEnabled = true;
            this.cmb_type.Items.AddRange(new object[] {
            "Normale",
            "Urgente",
            "Habituelle",
            "Inhabituelle"});
            this.cmb_type.Location = new System.Drawing.Point(221, 426);
            this.cmb_type.Name = "cmb_type";
            this.cmb_type.Size = new System.Drawing.Size(200, 21);
            this.cmb_type.TabIndex = 64;
            // 
            // cmb_description
            // 
            this.cmb_description.FormattingEnabled = true;
            this.cmb_description.Items.AddRange(new object[] {
            "Non important",
            "Important",
            "Très important"});
            this.cmb_description.Location = new System.Drawing.Point(221, 399);
            this.cmb_description.Name = "cmb_description";
            this.cmb_description.Size = new System.Drawing.Size(200, 21);
            this.cmb_description.TabIndex = 63;
            // 
            // txt_personneimplique
            // 
            this.txt_personneimplique.Location = new System.Drawing.Point(221, 269);
            this.txt_personneimplique.Multiline = true;
            this.txt_personneimplique.Name = "txt_personneimplique";
            this.txt_personneimplique.Size = new System.Drawing.Size(200, 124);
            this.txt_personneimplique.TabIndex = 62;
            // 
            // txt_emplacement
            // 
            this.txt_emplacement.Location = new System.Drawing.Point(221, 243);
            this.txt_emplacement.Name = "txt_emplacement";
            this.txt_emplacement.Size = new System.Drawing.Size(200, 20);
            this.txt_emplacement.TabIndex = 61;
            // 
            // txt_tolerance
            // 
            this.txt_tolerance.Location = new System.Drawing.Point(221, 217);
            this.txt_tolerance.Name = "txt_tolerance";
            this.txt_tolerance.Size = new System.Drawing.Size(200, 20);
            this.txt_tolerance.TabIndex = 60;
            // 
            // txt_nomtache
            // 
            this.txt_nomtache.Location = new System.Drawing.Point(221, 139);
            this.txt_nomtache.Name = "txt_nomtache";
            this.txt_nomtache.Size = new System.Drawing.Size(200, 20);
            this.txt_nomtache.TabIndex = 59;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(50, 426);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 58;
            this.label8.Text = "Type";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(50, 399);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 57;
            this.label7.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(50, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 13);
            this.label6.TabIndex = 56;
            this.label6.Text = "Personne(s) impliqué(s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(50, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 55;
            this.label5.Text = "Emplacement";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 54;
            this.label4.Text = "Tolérance";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(50, 198);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 13);
            this.label9.TabIndex = 53;
            this.label9.Text = "Date de fin";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(50, 172);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 52;
            this.label10.Text = "Date début";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(50, 146);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 13);
            this.label12.TabIndex = 51;
            this.label12.Text = "Nom de la tâche";
            // 
            // AjoutEnfant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 483);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.bt_ajouttache);
            this.Controls.Add(this.bt_enregister);
            this.Controls.Add(this.cmb_type);
            this.Controls.Add(this.cmb_description);
            this.Controls.Add(this.txt_personneimplique);
            this.Controls.Add(this.txt_emplacement);
            this.Controls.Add(this.txt_tolerance);
            this.Controls.Add(this.txt_nomtache);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cmb_niveau);
            this.Controls.Add(this.txt_nomecole);
            this.Controls.Add(this.txt_distance);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AjoutEnfant";
            this.Text = "AjoutEnfant";
            this.Load += new System.EventHandler(this.AjoutEnfant_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_niveau;
        private System.Windows.Forms.TextBox txt_nomecole;
        private System.Windows.Forms.TextBox txt_distance;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button bt_ajouttache;
        private System.Windows.Forms.Button bt_enregister;
        private System.Windows.Forms.ComboBox cmb_type;
        private System.Windows.Forms.ComboBox cmb_description;
        private System.Windows.Forms.TextBox txt_personneimplique;
        private System.Windows.Forms.TextBox txt_emplacement;
        private System.Windows.Forms.TextBox txt_tolerance;
        private System.Windows.Forms.TextBox txt_nomtache;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
    }
}