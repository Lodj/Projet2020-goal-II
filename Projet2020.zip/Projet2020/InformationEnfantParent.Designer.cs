﻿namespace Projet2020
{
    partial class InformationEnfantParent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_distance = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_nomecole = new System.Windows.Forms.TextBox();
            this.cmb_niveau = new System.Windows.Forms.ComboBox();
            this.bt_planingenfant = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_distance
            // 
            this.txt_distance.Location = new System.Drawing.Point(410, 111);
            this.txt_distance.Name = "txt_distance";
            this.txt_distance.Size = new System.Drawing.Size(121, 20);
            this.txt_distance.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(239, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "Distance entre l\'école et la maison";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(239, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Nom d\'école";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(239, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Niveau d\'études";
            // 
            // txt_nomecole
            // 
            this.txt_nomecole.Location = new System.Drawing.Point(410, 85);
            this.txt_nomecole.Name = "txt_nomecole";
            this.txt_nomecole.Size = new System.Drawing.Size(121, 20);
            this.txt_nomecole.TabIndex = 32;
            this.txt_nomecole.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // cmb_niveau
            // 
            this.cmb_niveau.FormattingEnabled = true;
            this.cmb_niveau.Items.AddRange(new object[] {
            "Primaire 1ère année",
            "Primaire 2ème année",
            "Primaire 3ème année",
            "Primaire 4ème année",
            "Primaire 5ème année",
            "Primaire 6ème année",
            "Moyen secondaire 1ère année",
            "Moyen secondaire 2ème année",
            "Moyen secondaire 3ème année",
            "Secondaire 1ère année",
            "Secondaire 2ème année",
            "Secondaire 3ème année",
            "Secondaire 4ème année",
            "Licence 1",
            "Licence 2",
            "Licence 3",
            "Master 1",
            "Master 2",
            "Doctorat"});
            this.cmb_niveau.Location = new System.Drawing.Point(410, 58);
            this.cmb_niveau.Name = "cmb_niveau";
            this.cmb_niveau.Size = new System.Drawing.Size(121, 21);
            this.cmb_niveau.TabIndex = 33;
            // 
            // bt_planingenfant
            // 
            this.bt_planingenfant.Location = new System.Drawing.Point(272, 168);
            this.bt_planingenfant.Name = "bt_planingenfant";
            this.bt_planingenfant.Size = new System.Drawing.Size(101, 23);
            this.bt_planingenfant.TabIndex = 34;
            this.bt_planingenfant.Text = "Planing Enfant";
            this.bt_planingenfant.UseVisualStyleBackColor = true;
            this.bt_planingenfant.Click += new System.EventHandler(this.bt_planingenfant_Click);
            // 
            // InformationEnfantParent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Projet2020.Properties.Resources.parent;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt_planingenfant);
            this.Controls.Add(this.cmb_niveau);
            this.Controls.Add(this.txt_nomecole);
            this.Controls.Add(this.txt_distance);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "InformationEnfantParent";
            this.Text = "InformationEnfantParent";
            this.Load += new System.EventHandler(this.InformationEnfantParent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_distance;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_nomecole;
        private System.Windows.Forms.ComboBox cmb_niveau;
        private System.Windows.Forms.Button bt_planingenfant;
    }
}